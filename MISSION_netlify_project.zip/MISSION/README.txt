MISSION — separate Netlify project
==================================

FILES
- index.html: the current MISSION mixed-reality prototype
- netlify/functions/mission.mts: AI assistant endpoint at /api/mission
- netlify/functions/mission-search.mts: live web-search endpoint at /api/mission-search
- netlify.toml: Netlify build configuration

DEPLOY
1. Create a NEW, separate Netlify site for MISSION. Do not use the Clean Cuts site.
2. Upload/deploy this entire project folder (or connect a Git repository containing it).
3. In the new MISSION site's environment variables, add:
   OPENAI_API_KEY = your secret OpenAI API key
   OPENAI_MODEL = gpt-6.2-astra
   Set the variable scope to include Functions.
4. Save the variables and trigger a fresh deploy.
5. Open the deployed site and test the MISSION chat and Search button.

IMPORTANT
- Never paste your API key into index.html, a public file, or a chat message.
- Ask a parent/guardian to help with API account setup, billing, and usage limits. ChatGPT subscriptions and API billing are separate.
- API usage can cost money. Set an API usage budget/alerts in the API account before testing.
- The app is a prototype. Quest passthrough and controller calibration still need real-headset testing.
- MISSION is designed for fictional holographic target practice, not real-world weapons or combat.

MODEL NOTE
The project defaults to gpt-6.2-astra, matching the current OpenAI web-search guide. If that model is not enabled for the API account, change OPENAI_MODEL in Netlify to a model shown as available in that account, then redeploy.
