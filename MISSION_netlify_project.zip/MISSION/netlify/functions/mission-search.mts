import type { Config, Context } from "@netlify/functions";

const SEARCH_INSTRUCTIONS = `You are MISSION's web research assistant inside a fictional mixed-reality arcade game. Answer the user's question using current web search results. Be accurate, concise, and age-appropriate. Clearly distinguish verified facts from uncertainty. Never provide real-world weapon instructions, combat tactics, or guidance that could help someone hurt another person. Return a useful summary and rely on the web search citations supplied by the platform. Do not claim to have searched if the search tool did not run.`;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

export default async (req: Request, _context: Context) => {
  if (req.method !== "POST") return json({ error: "Use POST for MISSION search." }, 405);
  const apiKey = Netlify.env.get("OPENAI_API_KEY");
  if (!apiKey) return json({ error: "MISSION search is not configured. Add OPENAI_API_KEY in Netlify environment variables, then redeploy." }, 503);

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "The request body must be valid JSON." }, 400); }
  const query = typeof body?.message === "string" ? body.message.trim() : "";
  if (!query) return json({ error: "Enter something for MISSION to search." }, 400);
  if (query.length > 800) return json({ error: "Please keep search requests under 800 characters." }, 413);

  const model = Netlify.env.get("OPENAI_MODEL") || "gpt-6.2-astra";
  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model,
        instructions: SEARCH_INSTRUCTIONS,
        tools: [{ type: "web_search", search_context_size: "medium" }],
        tool_choice: "required",
        include: ["web_search_call.action.sources"],
        input: query,
        max_output_tokens: 650,
      }),
    });
    const data: any = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI web search error", upstream.status, data?.error?.type || "unknown");
      return json({ error: "Live search could not complete. Check the model setting and API account access." }, 502);
    }
    const answer = typeof data.output_text === "string" ? data.output_text.trim() : "";
    const sources = new Map<string, string>();
    for (const item of data.output || []) {
      for (const content of item.content || []) {
        for (const annotation of content.annotations || []) {
          if (annotation.type === "url_citation" && annotation.url) {
            sources.set(annotation.url, annotation.title || annotation.url);
          }
        }
      }
      for (const source of item.action?.sources || []) {
        if (source.url) sources.set(source.url, source.title || source.url);
      }
    }
    if (!answer) return json({ error: "Search returned no summary. Try a more specific question." }, 502);
    return json({ answer, sources: [...sources].slice(0, 6).map(([url, title]) => ({ url, title })) });
  } catch (error) {
    console.error("MISSION search failed", error);
    return json({ error: "MISSION could not reach live search. Please try again." }, 502);
  }
};

export const config: Config = { path: "/api/mission-search", method: "POST" };
